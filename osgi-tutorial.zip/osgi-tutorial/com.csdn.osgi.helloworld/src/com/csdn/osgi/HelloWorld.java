package com.csdn.osgi;

public class HelloWorld {

	public HelloWorld() {
		System.out.println("================Hello World================");
	}
}
