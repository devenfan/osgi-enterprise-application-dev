package com.csdn.osgi.domain;

public interface Employee {

	public String getName();

	public int getAge();

	public String getAddress();

}
